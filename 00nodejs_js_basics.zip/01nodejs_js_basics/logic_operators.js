// In JavaScript we can use logic operators to combine bools

console.log("true and false = " + (true && false));
console.log("true and true = " + (true && true));

console.log("true or true = " + (true || true));
console.log("true or false = " + (true || false));
console.log("false or false = " + (false || false));
