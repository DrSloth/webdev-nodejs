// Comments are started with a double slash (//) in JavaScript

/*
They can even span multiple lines.
However i don't really use this kind of style to comment and only to "comment out" code.
*/
