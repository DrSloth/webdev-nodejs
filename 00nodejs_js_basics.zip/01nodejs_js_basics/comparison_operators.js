// Comparison operators are used to compare values, they are often used together with if, while etc

console.log("10 > 5 = " + (10 > 5));
console.log("10 < 5 = " + (10 < 5));
console.log("10 == 5 = " + (10 == 5));
console.log("10 != 5 = " + (10 != 5));
console.log("10 >= 5 = " + (10 >= 5));
console.log("10 <= 5 = " + (10 <= 5));
