// Strings can be concatenated using the + operator in JavaScript
console.log("Hello" + "World");

// If one of the operands is not a string it will be automatically converted
console.log(1 + ". The meaning of life is: " + 42);
