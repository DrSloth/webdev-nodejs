// JavaScript supports basic arithmetic operators for numbers.

let plus = 10 + 5;
console.log("10 + 5 = " + plus);

let minus = 10 - 5;
console.log("10 - 5 = " + minus);

let mul = 10 * 5;
console.log("10 * 5 = " + mul);

let divide = 10 / 5;
console.log("10 / 5 = " + divide);

let modulo = 11 % 5;
console.log("Reminder of 11 / 5 is " + modulo);
