// In Python we used print to print to the console. We use console.log in JavaScript for that.

// A simple hello world program
console.log("Hello, World!");

// You can also print to the consoles error output with console.error
console.error("Error");
