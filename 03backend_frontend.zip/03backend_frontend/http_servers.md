What we need in order to give a client these resources is called an http server.

Http servers listen to network requests, then parse the and build a valid response.
Luckily we don't have to be concerned with that because we can use the one provided by node.js
