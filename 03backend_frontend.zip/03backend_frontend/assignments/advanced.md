Write a simple http server program which responds with a file that is located at the path 
given as requested resource in the url relative to the working directory.

The request to `/hello.txt` should forward to the file `./hello.txt` and so on.
